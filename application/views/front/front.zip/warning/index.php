<section class="slice sct-color-1">
    <div class="container" >
        <div class="section-title section-title--style-1 text-center mb-4">
            <h3 class="section-title-inner heading-1" style="margin-bottom: 0px !important;line-height: 0px; font-size: 4rem !important;font-family: 'Tangerine', serif;text-shadow: 4px 4px 4px #aaa;">
                Warning And Suspensions
            </h3>
            <span class="section-title-delimiter clearfix d-none"></span>
        </div>
        <span class="clearfix"></span>
        <br/>
        <div style=" color: black; font-size: 1.2rem;">
            Match Made In Jannah expects Islamic etiquettes to be maintained between all members. Unfortunately though, there are times when some members break the rules.<br/>
			Our moderators will offer you up to 3 warnings on a certain rule break prior to suspending your account. Please do not ignore those warnings. The warnings are given to members who break our rules in order to keep our site halal.<br/>
			Here's how it works:<br/>
			<b>Warnings</b> - are issued to those who break the following rules:<br/>
			<ul>
			<li>Being rude/impolite</li>
			<li>Being pushy with members</li>
			</ul>
			<b>Suspensions</b> - can be temporary or permanent in which case they would<br/>
			automatically become a ban. Those who can be suspended or banned include members who :<br/>
			<ul>
			<li>Repeatedly break the above rules </li>
			<li>Having multiple accounts to contact several members  </li>
			<li>Abusing other members repeatedly  </li>
			<li>Attempting to fraud other members by asking for money  </li>
			</ul>



        </div>
    </div>
</section>
  