<section class="slice sct-color-1">
    <div class="container">
        <div class="section-title section-title--style-1 text-center mb-4">
             <h3 class="section-title-inner heading-1" style="margin-bottom: 0px !important;line-height: 0px; font-size: 4rem !important;font-family: 'Tangerine', serif;text-shadow: 4px 4px 4px #aaa;">
                Honesty Is The Best Policy
            </h3>
            <span class="section-title-delimiter clearfix d-none"></span>
        </div>

        <span class="clearfix"></span>
<br/>
       <div style=" color: black; font-size: 1.2rem;">

Match Made In Jannah requests every member to be honest with each other.  It is better to tell the truth than to hide behind lies which only leads to destruction.<br/><br/>

When marriage is discussed between two people, they start to plan their life with hopes and dreams full of aspirations which forms the foundation of their decision to move forward. They effectively put their heart & soul on the line.  However, there could be times, when certain people are dishonest and try to mislead or play games for their own interests, not realizing how devasting and hurtful the other person will be.  So, we request everyone to make wise judgements before trusting someone.<br/><br/> 

Muhammad (SAW) said there are three things in Islam which are not matters to be joked about, and the first of these is marriage. <br/><br/> 

Furthermore, the Prophet SAW said that the angels distance themselves from the liar, and this a evil trait which is not a characteristic we desire from our candidates.<br/><br/>

Abdullah bin Umar (RA) relates that Prophet SAW said: When a person lies, the angel distances himself from the liar by a mile." (Tirmidhi).<br/><br/>

The Prophet SAW said: ‘There are three things which, whether undertaken seriously or in jest, are treated as serious: <br/><br/>
<ul>
<li>Marriage</li>
<li>Divorce</li>
<li>taking back a wife (after a divorce which is not final).</li>
</ul>
Sunan of Abu-Dawood Hadith 2189, 
Narrated by Abu Hurayrah: 

Match Made In Jannah, wants to see everyone find their partners which Allah has created for each and every one of you, so please start by being honest. <br/><br/>
May Allah bless you more…..Ameen<br/><br/>


 

        </div>
    </div>
</section>